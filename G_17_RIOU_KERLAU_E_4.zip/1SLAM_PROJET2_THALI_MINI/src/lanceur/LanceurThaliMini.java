package lanceur;

import modele.dao.DaoEtape;
import modele.dao.DaoMiniExcursion;
import gui.JFrameLesExcursions;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;
import javax.swing.JOptionPane;
import modele.metier.Etape;
import modele.metier.MiniExcursion;

/**
 *
 * @author nicolas
 */
public class LanceurThaliMini {


    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        // Variables destinées à initialiser les données affichées au démarrage
        ArrayList<MiniExcursion> lesExcursions;
        ArrayList<Etape> lesEtapes = null;
        MiniExcursion excursionCourante = null;
        try {
            // récupérer la liste des excursions
            lesExcursions = DaoMiniExcursion.getAll();
            // La première excursion est l'excursion courante
            excursionCourante = lesExcursions.get(0);
            
            // Instancier la fenêtre initiale et lui fournir les données à afficher
            JFrameLesExcursions jf = new JFrameLesExcursions();
            jf.remplirJComBoxExcursions(lesExcursions);
            jf.raffraichirJTableEtapes(0);
            jf.setLocation(300, 300);
            jf.setVisible(true);
        } catch (SQLException | IOException ex) {
            String message = "Echec de lecture initiale des données dans la BDD";
            Logger.getLogger(LanceurThaliMini.class.getName()).log(Level.SEVERE, message, ex);
            JOptionPane.showMessageDialog(null, message, "Lanceur", JOptionPane.ERROR_MESSAGE);
            System.exit(1);
        }
        
        

    }

}
